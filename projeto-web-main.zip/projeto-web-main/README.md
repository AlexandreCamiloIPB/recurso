# Visual Studio Code
## Instalar extensões
1. Sass/Less/Stylus/Pug/Jade/Typescript/Javascript Compile Hero Pro - [https://marketplace.visualstudio.com/items?itemName=Wscats.eno]()
2. ftp-sync - [https://marketplace.visualstudio.com/items?itemName=lukasz-wronski.ftp-sync]()

**Tarefas extra** para a extenão n.1: 
1. Copiar a pasta wscats.eno-2.3.53 (Extras) para \<HOME DIRECTORY\>\\.vscode\\extensions
2. Reiniciar o Visual Studio Code

  ## Links uteis:

Bootstrap + PUG - [https://github.com/pug-bootstrap/PUG-Bootstrap]()

# Markdown - md
Open source online Markdown editor - [https://pandao.github.io/editor.md/en.html]()
