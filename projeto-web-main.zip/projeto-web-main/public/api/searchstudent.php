<?php

echo json_encode(array('result' => false));

?>